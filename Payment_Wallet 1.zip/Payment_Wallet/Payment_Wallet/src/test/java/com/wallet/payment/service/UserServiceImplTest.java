package com.wallet.payment.service;

import com.wallet.payment.Dto.request.CurrencyDetailsRequestDto;
import com.wallet.payment.Dto.request.UserRequestDto;
import com.wallet.payment.Dto.request.WalletAmountRequestDto;
import com.wallet.payment.Dto.response.BalanceResponseDTO;
import com.wallet.payment.entity.Currency;
import com.wallet.payment.entity.Transaction;
import com.wallet.payment.entity.User;
import com.wallet.payment.entity.Wallet;
import com.wallet.payment.exception.InvalidCurrencyException;
import com.wallet.payment.exception.UserAlreadyExistException;
import com.wallet.payment.exception.UserNotFoundException;
import com.wallet.payment.repository.CurrencyRepository;
import com.wallet.payment.repository.TransactionRepository;
import com.wallet.payment.repository.UserRepository;
import com.wallet.payment.repository.WalletRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@SpringBootTest
public class UserServiceImplTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private CurrencyRepository currencyRepository;

    @Mock
    private WalletRepository walletRepository;

    @Mock
    private TransactionRepository transactionRepository;

    @InjectMocks
    private UserServiceImpl userService;

    @Mock
    private ModelMapper modelMapper;

    private UserRequestDto requestDto;

    @BeforeEach
    public void setUp() {
        modelMapper = new ModelMapper();
        requestDto = UserRequestDto.builder()
                .email("prabhu@gmail.com")
                .password("727871@Prabhu")
                .userName("Prabhuling")
                .build();
    }

    @Test
    @DisplayName("Test case for create wallet account")
    public void createWalletAccountTest() {
        // Mock data
        User user = modelMapper.map(requestDto, User.class);
        System.out.println(user);

        when(userRepository.findByUserName(any())).thenReturn(Optional.empty());
        when(userRepository.save(any())).thenReturn(user);

        // Call the method under test
        User savedUser = userService.createWalletAccount(requestDto);

        // Assertions
        Assertions.assertNotNull(savedUser);
        Assertions.assertEquals(requestDto.getEmail(), savedUser.getEmail());

        // Verify interactions (optional, depending on your needs)
        verify(userRepository, times(1)).findByUserName(any());
        verify(userRepository, times(1)).save(any());
    }

    @DisplayName("Test case for User already exist exception ")
    public void createWalletAccountUserAlreadyExistException(){
        // Mock data
        User user = modelMapper.map(requestDto, User.class);
        System.out.println(user);

        when(userRepository.findByUserName(any())).thenReturn(Optional.of(user));

        // Call the method under test

        Assertions.assertThrows(UserAlreadyExistException.class,
                ()->userService.createWalletAccount(requestDto));

        verify(userRepository, never()).save(any(User.class));

    }

    @Test
    @DisplayName("Test case for add amount to wallet")
    public void addAmountToWalletTest(){
        WalletAmountRequestDto walletAmountRequestDto = WalletAmountRequestDto.builder()
                .userId(1L)
                .currencyId(2L)
                .balance(2000.0)
                .build();

        Currency currency= Currency.builder()
                .name("INR")
                .currencyId(2L)
                .abbreviation("INDIAN CURRENCY")
                .build();

        User user= User.builder()
                .userName("Test")
                .email("test@gmail.com")
                .userId(1L)
                .password("727871@test.com")
                .build();

        Wallet wallet = Wallet.builder().walletId(1L)
                        .currency(currency)
                        .user(user)
                        .balance(3000.0).build();

        Transaction transaction =new Transaction();
        transaction.setAmount(walletAmountRequestDto.getBalance());
        transaction.setWallet(wallet);
        transaction.setLocalDateTime(LocalDateTime.now());

        when(userRepository.findById(any())).thenReturn(Optional.of(user));
        when(currencyRepository.findById(any())).thenReturn(Optional.of(currency));
        when(walletRepository.findByUser(any())).thenReturn(Optional.of(wallet));

        wallet.setBalance(wallet.getBalance()+walletAmountRequestDto.getBalance());

        when(walletRepository.save(any())).thenReturn(wallet);
        when(transactionRepository.save(any())).thenReturn(transaction);

        userService.addAmountToWallet(walletAmountRequestDto);

        verify(userRepository,times(1)).findById(any());
        verify(currencyRepository,times(1)).findById(any());
        verify(walletRepository,times(1)).findByUser(any());
        verify(walletRepository,times(1)).save(any());
        verify(transactionRepository,times(1)).save(any());


    }


    @Test
    @DisplayName("Test case for add amount to new wallet Account")
    public void addAmountToNewWalletAccountTest(){
        WalletAmountRequestDto walletAmountRequestDto = WalletAmountRequestDto.builder()
                .userId(1L)
                .currencyId(2L)
                .balance(2000.0)
                .build();

        Currency currency= Currency.builder()
                .name("INR")
                .currencyId(2L)
                .abbreviation("INDIAN CURRENCY")
                .build();

        User user= User.builder()
                .userName("Test")
                .email("test@gmail.com")
                .userId(1L)
                .password("727871@test.com")
                .build();

        Wallet wallet = Wallet.builder().walletId(1L)
                .currency(currency)
                .user(user)
                .balance(3000.0).build();

        Transaction transaction =new Transaction();
        transaction.setAmount(walletAmountRequestDto.getBalance());
        transaction.setWallet(wallet);
        transaction.setLocalDateTime(LocalDateTime.now());

        when(userRepository.findById(any())).thenReturn(Optional.of(user));
        when(currencyRepository.findById(any())).thenReturn(Optional.of(currency));
        when(walletRepository.findByUser(any())).thenReturn(Optional.empty());

        wallet.setBalance(wallet.getBalance()+walletAmountRequestDto.getBalance());

        when(walletRepository.save(any())).thenReturn(wallet);
        when(transactionRepository.save(any())).thenReturn(transaction);

        userService.addAmountToWallet(walletAmountRequestDto);

        verify(userRepository,times(1)).findById(any());
        verify(currencyRepository,times(1)).findById(any());
        verify(walletRepository,times(1)).findByUser(any());
        verify(walletRepository,times(1)).save(any());
        verify(transactionRepository,times(1)).save(any());


    }

    @Test
    @DisplayName("Test case for user not found Exception ")
    public void validateUserMethodWithUserNotFoundExceptionTest(){

        when(userRepository.findById(any())).thenReturn(Optional.empty());
        Assertions.assertThrows(UserNotFoundException.class,()->userService.validateUser(1L));

    }

    @Test
    @DisplayName("Test case for Invalid currency exception")
    public void validateCurrencyTypeMethodWithInvalidCurrencyException(){
        when(currencyRepository.findById(any())).thenReturn(Optional.empty());
        Assertions.assertThrows(InvalidCurrencyException.class,()->userService.validateCurrencyType(2L));
    }


    @Test
    @DisplayName("Test case for save currency")
    public void saveCurrencyDetailsTest(){
        CurrencyDetailsRequestDto requestDto = CurrencyDetailsRequestDto.builder()
                .name("INR")
                .abbreviation("INDIAN CURRENCY")
                .build();
        Currency currency = modelMapper.map(requestDto, Currency.class);

        when(currencyRepository.findByName(any())).thenReturn(Optional.empty());
        when(currencyRepository.save(any())).thenReturn(currency);

        userService.saveCurrencyDetails(requestDto);

        verify(currencyRepository,times(1)).findByName(any());
        verify(currencyRepository,times(1)).save(any());

    }


    @Test
    @DisplayName("Test case for getting Balance")
    public void balanceDetailsTest(){
        User user= User.builder()
                .userName("Test")
                .email("test@gmail.com")
                .userId(1L)
                .password("727871@test.com")
                .build();

        Wallet wallet = Wallet.builder().walletId(1L)
                .user(user)
                .balance(3000.0).build();

        when(userRepository.findById(any())).thenReturn(Optional.of(user));
        when(walletRepository.findByUser(any())).thenReturn(Optional.of(wallet));

        BalanceResponseDTO responseDTO =userService.balanceDetails(1L);

        Assertions.assertNotNull(responseDTO);
        Assertions.assertTrue(responseDTO.getBalance() >0);
        verify(userRepository,times(1)).findById(any());
        verify(walletRepository,times(1)).findByUser(any());

    }

}
