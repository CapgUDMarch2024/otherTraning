package com.wallet.payment.repository;

import com.wallet.payment.entity.User;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.Optional;

@DataJpaTest
public class UserRepositoryTests {

    @Autowired
    private UserRepository userRepository;

    //Junit test for save user operation
    @DisplayName("Test case for create user wallet Account")
    @Test
    @Order(1)
    public void createWalletAccountTest(){
        //given - precondition or setup

        User user = User.builder().userName("Prabhu")
                .email("Prabhu@gmail.com")
                .password("727871@Prabhu")
                .build();

        //when - action or behaviour that we are going to test
        User savedUser = userRepository.save(user);

        //then - verify the output
        Assertions.assertNotNull(savedUser);
        Assertions.assertTrue(savedUser.getUserId()>0);

    }


    @Order(2)
    @Test
    @DisplayName("Test case for get user by Name")
    public void findByUserNameTest(){

        User user = User.builder().userName("Prabhu")
                .email("Prabhu@gmail.com")
                .password("727871@Prabhu")
                .build();

        //when - action or behaviour that we are going to test
       userRepository.save(user);


        Optional<User> optionalUser = userRepository.findByUserName("Prabhu");

        Assertions.assertNotNull(optionalUser.get());
        Assertions.assertEquals("Prabhu@gmail.com",optionalUser.get().getEmail());

    }


}
