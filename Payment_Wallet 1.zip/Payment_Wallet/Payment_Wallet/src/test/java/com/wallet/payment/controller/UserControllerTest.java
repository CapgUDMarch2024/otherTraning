package com.wallet.payment.controller;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wallet.payment.Dto.request.CurrencyDetailsRequestDto;
import com.wallet.payment.Dto.request.UserRequestDto;
import com.wallet.payment.Dto.request.WalletAmountRequestDto;
import com.wallet.payment.Dto.response.BalanceResponseDTO;
import com.wallet.payment.service.UserService;


import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.internal.verification.VerificationModeFactory.times;
import static org.mockito.Mockito.*;

@WebMvcTest(controllers = UserController.class)
public class UserControllerTest {

    @MockBean
    private UserService userServiceMock;

    @Autowired
    private MockMvc mockMvc;

    @Test
    @DisplayName("Test case for create wallet account")
    public void createWalletAccountTest() throws Exception {

        UserRequestDto requestDto =UserRequestDto.builder()
                .userName("Prabhu")
                .password("727871@Prabhu")
                .email("prabhu@gmail.com").build();

        mockMvc.perform(MockMvcRequestBuilders.post("/user/wallet-account")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(new ObjectMapper().writeValueAsString(requestDto)))
                .andExpect(MockMvcResultMatchers.status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("$.message")
                        .value("User Wallet account created successfully."));

        verify(userServiceMock,times(1)).createWalletAccount(any(UserRequestDto.class));


    }


    @Test
    @DisplayName("Test case for add amount to wallet")
    public void addAmountToWalletTest() throws Exception {
        WalletAmountRequestDto walletAmountRequestDto = WalletAmountRequestDto.builder()
                .userId(1L)
                .currencyId(2L)
                .balance(2000.0)
                .build();

        mockMvc.perform(MockMvcRequestBuilders.post("/user/wallet-amount")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON)  // Correct Accept header
                .content(new ObjectMapper().writeValueAsString(walletAmountRequestDto)))
                .andExpect(MockMvcResultMatchers.status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("$.message")
                        .value("Amount added to wallet successfully."));

        verify(userServiceMock,times(1)).addAmountToWallet(any(WalletAmountRequestDto.class));
    }


    @Test
    @DisplayName("Test case for save currency")
    public void saveCurrencyDetailsTest() throws Exception {

        CurrencyDetailsRequestDto currencyDetails = CurrencyDetailsRequestDto.builder()
                .name("INR")
                .abbreviation("INDIAN CURRENCY").build();
        mockMvc.perform(MockMvcRequestBuilders.post("/user/currency-details")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(currencyDetails)))
                        .andExpect(MockMvcResultMatchers.status().isCreated())
                                .andExpect(MockMvcResultMatchers.jsonPath("$.message").value("Currency details created Successfully."));

        verify(userServiceMock,times(1)).saveCurrencyDetails(any(CurrencyDetailsRequestDto.class));

    }

    @Test
    @DisplayName("Test case for get balance from wallet")
    public void balanceDetailsTest() throws Exception {
        BalanceResponseDTO balanceResponseDTO = BalanceResponseDTO.builder()
                .userId(2L)
                .balance(2000.0).build();
        when(userServiceMock.balanceDetails(anyLong())).thenReturn(balanceResponseDTO);

        mockMvc.perform(MockMvcRequestBuilders.get("/user/balance").param("userId","2")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.userId").value(2L))
                .andExpect(MockMvcResultMatchers.jsonPath("$.balance").value(2000.0));

    }

}
