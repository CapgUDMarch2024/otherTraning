package com.wallet.payment.repository;

import com.wallet.payment.entity.Currency;
import com.wallet.payment.entity.Transaction;
import com.wallet.payment.entity.User;
import com.wallet.payment.entity.Wallet;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.time.LocalDateTime;

@DataJpaTest
public class TransactionRepositoryTests {


    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CurrencyRepository currencyRepository;

    @Autowired
    private WalletRepository walletRepository;

    @Test
    public void saveTransactionTest(){

        User user =User.builder()
                .email("prabhu@gmail.com")
                .userName("Prabhu")
                .password("727871@Prabhu")
                .build();
        User savedUser = userRepository.save(user);

        Currency currency = Currency.builder()
                .name("INR")
                .abbreviation("INDIAN").build();

        Currency savedCurrency = currencyRepository.save(currency);

        Wallet wallet = Wallet.builder()
                .balance(20000.0)
                .user(savedUser)
                .currency(savedCurrency).build();

        Wallet savedWallet = walletRepository.save(wallet);

        Transaction transaction =Transaction.builder()
                .amount(20000.0)
                .status("ACTIVE")
                .wallet(savedWallet)
                .localDateTime(LocalDateTime.now()).build();

        Transaction savedTransaction = transactionRepository.save(transaction);

        Assertions.assertNotNull(savedTransaction);
        Assertions.assertNotNull(savedTransaction.getWallet());
        Assertions.assertEquals(20000.0,savedTransaction.getAmount());



    }

}
