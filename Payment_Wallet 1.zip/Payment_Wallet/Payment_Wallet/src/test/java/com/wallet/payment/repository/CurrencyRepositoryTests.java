package com.wallet.payment.repository;

import com.wallet.payment.entity.Currency;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.Optional;

@DataJpaTest
public class CurrencyRepositoryTests {

    @Autowired
    private CurrencyRepository currencyRepository;
    @Test
    @DisplayName("Test case for save currency")
    public void saveCurrencyTest(){

        Currency currency = Currency.builder()
                .name("INR")
                .abbreviation("INDIAN CURRENCY").build();

        Currency savedCurrency = currencyRepository.save(currency);

        Assertions.assertNotNull(savedCurrency);
        Assertions.assertEquals("INR",savedCurrency.getName());
        Assertions.assertTrue(savedCurrency.getCurrencyId()>0);

    }

    @Test
    @DisplayName("Test case for find currency by name")
    public void getCurrencyByName(){
        Currency currency = Currency.builder()
                .name("INR")
                .abbreviation("INDIAN CURRENCY").build();

         currencyRepository.save(currency);

      Optional<Currency> optionalCurrency = currencyRepository.findByName("INR");

      Assertions.assertTrue(optionalCurrency.isPresent());
      Assertions.assertEquals("INDIAN CURRENCY",optionalCurrency.get().getAbbreviation());

    }
}
