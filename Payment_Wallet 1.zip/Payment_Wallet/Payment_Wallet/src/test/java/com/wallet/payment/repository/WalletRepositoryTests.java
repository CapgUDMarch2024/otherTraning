package com.wallet.payment.repository;

import com.wallet.payment.entity.Currency;
import com.wallet.payment.entity.User;
import com.wallet.payment.entity.Wallet;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

@DataJpaTest
public class WalletRepositoryTests {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CurrencyRepository currencyRepository;

    @Autowired
    private WalletRepository walletRepository;

    @Test
    public void saveWalletTest(){

        User user =User.builder()
                .email("prabhu@gmail.com")
                .userName("Prabhu")
                .password("727871@Prabhu")
                .build();
        User savedUser = userRepository.save(user);

        Currency currency = Currency.builder()
                .name("INR")
                .abbreviation("INDIAN").build();

        Currency savedCurrency = currencyRepository.save(currency);
        Wallet wallet = Wallet.builder()
                .user(savedUser)
                .balance(20000.0)
                .currency(savedCurrency).build();

        Wallet savedWallet = walletRepository.save(wallet);

        Assertions.assertNotNull(savedWallet);
        Assertions.assertNotNull(savedWallet.getCurrency());
        Assertions.assertEquals(20000.0,savedWallet.getBalance());

    }


}
