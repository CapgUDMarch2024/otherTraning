package com.wallet.payment.exception;

public class CurrencyAlreadyExistException extends RuntimeException{
    public CurrencyAlreadyExistException(String exception){
        super(exception);
    }
}
