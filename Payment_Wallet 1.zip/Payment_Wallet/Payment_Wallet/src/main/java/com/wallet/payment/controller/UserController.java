package com.wallet.payment.controller;

import com.wallet.payment.Dto.request.CurrencyDetailsRequestDto;
import com.wallet.payment.Dto.request.UserRequestDto;
import com.wallet.payment.Dto.request.WalletAmountRequestDto;
import com.wallet.payment.Dto.response.BalanceResponseDTO;
import com.wallet.payment.Dto.response.SuccessResponse;
import com.wallet.payment.entity.User;
import com.wallet.payment.service.UserService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
@Slf4j
public class UserController {

    private UserService userService;

    @Autowired
    public UserController(UserService userService){
        this.userService = userService;
    }

    @PostMapping(value = "/wallet-account" ,consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessResponse> createWalletAccount(@Valid  @RequestBody UserRequestDto userRequestDto){
        log.info("createWalletAccount started .");
        User user =userService.createWalletAccount(userRequestDto);
        return new ResponseEntity<>(new SuccessResponse("User Wallet account created successfully."), HttpStatus.CREATED);
    }

    @PostMapping(value = "/wallet-amount",consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
   public ResponseEntity<SuccessResponse> addAmountToWallet(@RequestBody WalletAmountRequestDto walletAmountRequestDto){
        log.info("addAmountToWallet started .");
        userService.addAmountToWallet(walletAmountRequestDto);
        return new ResponseEntity<>(new SuccessResponse("Amount added to wallet successfully."), HttpStatus.CREATED);
   }

   @PostMapping(value = "/currency-details")
   public ResponseEntity<SuccessResponse> saveCurrencyDetails(@RequestBody CurrencyDetailsRequestDto currencyDetailsRequestDto){
        log.info("saveCurrencyDetails started.");
        return new ResponseEntity<>(new SuccessResponse("Currency details created Successfully."),HttpStatus.CREATED);
   }

   @GetMapping("/balance")
   public ResponseEntity<BalanceResponseDTO> balanceDetails(@RequestParam(value = "userId") Long userId){
        log.info("balanceDetails started.");
        BalanceResponseDTO balanceResponseDto = userService.balanceDetails(userId);
        return new ResponseEntity<>(balanceResponseDto,HttpStatus.OK);
   }

}
