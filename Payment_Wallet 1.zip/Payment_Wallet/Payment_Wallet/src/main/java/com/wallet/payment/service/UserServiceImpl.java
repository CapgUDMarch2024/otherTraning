package com.wallet.payment.service;

import com.wallet.payment.Dto.request.CurrencyDetailsRequestDto;
import com.wallet.payment.Dto.request.UserRequestDto;
import com.wallet.payment.Dto.request.WalletAmountRequestDto;
import com.wallet.payment.Dto.response.BalanceResponseDTO;
import com.wallet.payment.entity.Currency;
import com.wallet.payment.entity.Transaction;
import com.wallet.payment.entity.User;
import com.wallet.payment.entity.Wallet;
import com.wallet.payment.exception.*;
import com.wallet.payment.repository.CurrencyRepository;
import com.wallet.payment.repository.TransactionRepository;
import com.wallet.payment.repository.UserRepository;
import com.wallet.payment.repository.WalletRepository;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
@Slf4j
public class UserServiceImpl implements UserService{

    private ModelMapper modelMapper;

    private UserRepository userRepository;

    private CurrencyRepository currencyRepository;

    private WalletRepository walletRepository;

    private TransactionRepository transactionRepository;

    @Autowired
    public UserServiceImpl(ModelMapper modelMapper, UserRepository userRepository,
                           CurrencyRepository currencyRepository, WalletRepository walletRepository,
                           TransactionRepository transactionRepository) {
        this.modelMapper = modelMapper;
        this.userRepository = userRepository;
        this.currencyRepository = currencyRepository;
        this.walletRepository = walletRepository;
        this.transactionRepository = transactionRepository;
    }

    @Override
    public User createWalletAccount(UserRequestDto userRequestDto) {

       Optional<User> userOptional= userRepository.findByUserName(userRequestDto.getUserName());
       if(userOptional.isPresent()){
          throw  new UserAlreadyExistException("User wallet account" +
                   " already exist with this user name : "+ userRequestDto.getUserName());
       }else{
           log.info("createWalletAccount ended.");
           User user =modelMapper.map(userRequestDto, User.class);
           return   userRepository.save(user);
       }
    }

    @Override
    @Transactional
    public void addAmountToWallet(WalletAmountRequestDto walletAmountRequestDto) {
      Currency currency =validateCurrencyType(walletAmountRequestDto.getCurrencyId());
      User user = validateUser(walletAmountRequestDto.getUserId());
      Optional<Wallet> wallet = walletRepository.findByUser(user);
      if(wallet.isPresent()){
          wallet.get().setBalance(wallet.get().getBalance() + walletAmountRequestDto.getBalance());
          walletRepository.save(wallet.get());
          saveTransactionDetails(wallet.get(),walletAmountRequestDto.getBalance());
      }else{
         Wallet walletAmount= new Wallet();
         walletAmount.setUser(user);
         walletAmount.setCurrency(currency);
         walletRepository.save(walletAmount);
         saveTransactionDetails(walletAmount,walletAmountRequestDto.getBalance());
      }

    }

    @Override
    public void saveCurrencyDetails(CurrencyDetailsRequestDto currencyDetailsRequestDto) {
      Optional<Currency> currencyOptional = currencyRepository.findByName(currencyDetailsRequestDto.getName());
      if(currencyOptional.isPresent()){
          throw new CurrencyAlreadyExistException("Currency already exists.");
      }else{
          Currency currency = modelMapper.map(currencyDetailsRequestDto,Currency.class);
          currencyRepository.save(currency);
      }
      log.info("saveCurrencyDetails ended.");
    }

    @Override
    public BalanceResponseDTO balanceDetails(Long userId) {
        User user = userRepository.findById(userId).orElseThrow(()->new UserNotFoundException("Account not found"));
        Wallet wallet = walletRepository.findByUser(user).orElseThrow(()->new UserWalletAccountNotFoundException("Wallet not found"));
        log.info("balanceDetails ended.");
        BalanceResponseDTO balanceResponseDTO = new BalanceResponseDTO();
        balanceResponseDTO.setBalance(wallet.getBalance());
        balanceResponseDTO.setUserId(wallet.getUser().getUserId());
        return balanceResponseDTO;
    }

    private void saveTransactionDetails(Wallet wallet, Double balance) {
        Transaction transaction =new Transaction();
        transaction.setAmount(balance);
        transaction.setWallet(wallet);
        transaction.setLocalDateTime(LocalDateTime.now());
        Transaction savedTransaction =  transactionRepository.save(transaction);
    }

    public User validateUser(Long userId) {
      return userRepository.findById(userId).orElseThrow(()->new UserNotFoundException("User not found"));
    }

    public Currency validateCurrencyType(Long currencyId) {
        return currencyRepository.findById(currencyId).orElseThrow(()->
                new InvalidCurrencyException("Invalid currency Id"));
    }
}
