package com.wallet.payment.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.FieldDefaults;

@Data
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Entity
@Table(name = "tbl_currency")
@Builder
public class Currency {

    @Id
     @GeneratedValue(strategy = GenerationType.AUTO)
    Long currencyId;
    String name;
    String abbreviation;

}
