package com.wallet.payment.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.FieldDefaults;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Entity
@Table(name = "tbl_transaction")
@Builder
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    Long transactionId;

    @ManyToOne
    @JoinColumn(name = "wallet_id", referencedColumnName = "walletId")
    Wallet wallet;

    String status;

    Double amount;

    LocalDateTime localDateTime;
}
