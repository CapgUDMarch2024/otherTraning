package com.wallet.payment.exception;

public class InvalidCurrencyException extends RuntimeException{
    public InvalidCurrencyException(String exception){
        super(exception);
    }
}
