package com.wallet.payment.exception;

public class UserWalletAccountNotFoundException extends RuntimeException{
    public UserWalletAccountNotFoundException(String exception){
        super(exception);
    }
}
