package com.wallet.payment.Dto.request;

import lombok.*;
import lombok.experimental.FieldDefaults;

@Data
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Builder
public class CurrencyDetailsRequestDto {
    String name;
    String abbreviation;
}
