package com.wallet.payment.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.FieldDefaults;

@Data
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Entity
@Table(name = "tbl_wallet")
@Builder
public class Wallet {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    Long walletId;
    @OneToOne(cascade = CascadeType.ALL)
    User user;


    @OneToOne(cascade = CascadeType.ALL)
    Currency currency;
    Double balance;
}
