package com.wallet.payment.Dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.*;
import lombok.experimental.FieldDefaults;

@Data
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Builder
public class UserRequestDto {

    @NotBlank(message = "user name should not be null or empty")
    String userName;

    @NotBlank(message = "email should not be null or empty")
    @Email
    String email;

    @NotEmpty
    @Size(min = 8, message = "password should have at least 8 characters")
    String password;
}
