package com.wallet.payment.service;


import com.wallet.payment.Dto.request.CurrencyDetailsRequestDto;
import com.wallet.payment.Dto.request.UserRequestDto;
import com.wallet.payment.Dto.request.WalletAmountRequestDto;
import com.wallet.payment.Dto.response.BalanceResponseDTO;
import com.wallet.payment.entity.User;

public interface UserService {
    User createWalletAccount(UserRequestDto userRequestDto);

    void addAmountToWallet(WalletAmountRequestDto walletAmountRequestDto);

    void saveCurrencyDetails(CurrencyDetailsRequestDto currencyDetailsRequestDto);

    BalanceResponseDTO balanceDetails(Long userId);
}
